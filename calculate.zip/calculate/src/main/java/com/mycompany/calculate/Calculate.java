/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculate;

/**
 *
 * @author isuru
 */
public class Calculate {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
